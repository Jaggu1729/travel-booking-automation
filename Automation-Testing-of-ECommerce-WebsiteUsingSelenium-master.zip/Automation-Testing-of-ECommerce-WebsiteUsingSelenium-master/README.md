# Automation-Testing-of-ECommerce-WebsiteUsingSelenium
- Java
- Maven
- TestNG
- BDD
- DDT 
- POM (Page Object Model)
- Selenium Grid
- Sauce Labs
- Zalenium 
- Docker
- Allure Test Report
- Jenkins Pipeline
-  Slack Integration into Jenkins File
# Integrated Development Environment 
- Eclipse IDEA
- IntelliJ IDEA

- It’s demo project https://demo.nopcommerce.com/ , I used Selenium Framework in this project.

