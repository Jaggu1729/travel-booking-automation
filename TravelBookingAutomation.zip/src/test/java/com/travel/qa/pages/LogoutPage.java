package com.travel.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LogoutPage {
    WebDriver driver;

    By profileIcon = By.id("profileIcon");
    By logoutLink = By.id("logout");

    public LogoutPage(WebDriver driver) {
        this.driver = driver;
    }

    public void logout() {
        driver.findElement(profileIcon).click();
        driver.findElement(logoutLink).click();
    }
}
