package com.travel.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SearchPage {
    WebDriver driver;

    By destinationInput = By.id("destination");
    By travelDateInput = By.id("travelDate");
    By searchButton = By.id("searchBtn");

    public SearchPage(WebDriver driver) {
        this.driver = driver;
    }

    public void searchTrip(String destination, String date) {
        driver.findElement(destinationInput).sendKeys(destination);
        driver.findElement(travelDateInput).sendKeys(date);
        driver.findElement(searchButton).click();
    }
}
